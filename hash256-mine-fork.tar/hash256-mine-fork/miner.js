require("dotenv").config();

const { ethers } = require("ethers");
const { CpuMiner } = require("./lib/cpu-miner");
const { OpenClMiner } = require("./lib/opencl-miner");
const { ABI, CONTRACT_ADDRESS, readOptions } = require("./lib/config");
const { Tui, colors } = require("./lib/tui");

const RPC_URL = process.env.RPC_URL;
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const SUBMIT_RPC_URL = process.env.SUBMIT_RPC_URL || "https://rpc.flashbots.net/fast";

const tui = new Tui();

function fail(msg) {
  tui.cleanup();
  console.error(msg);
  process.exit(1);
}

function requireEnv() {
  if (!RPC_URL || !PRIVATE_KEY) {
    fail("Isi RPC_URL dan PRIVATE_KEY di file .env dulu.\nContoh: cp .env.example .env lalu edit PRIVATE_KEY.");
  }
  if (!PRIVATE_KEY.startsWith("0x")) {
    fail("PRIVATE_KEY harus diawali 0x.");
  }
}

async function main() {
  requireEnv();
  const options = readOptions();

  // Split read / submit RPCs so mine() goes through private orderflow (Flashbots Protect).
  const readProvider = new ethers.JsonRpcProvider(RPC_URL);
  const submitProvider = new ethers.JsonRpcProvider(SUBMIT_RPC_URL);
  const wallet = new ethers.Wallet(PRIVATE_KEY, submitProvider);
  const readContract = new ethers.Contract(CONTRACT_ADDRESS, ABI, readProvider);
  const submitContract = new ethers.Contract(CONTRACT_ADDRESS, ABI, wallet);

  tui.update({
    address: wallet.address,
    backend: options.backend,
    submitRpc: shortRpc(SUBMIT_RPC_URL),
    status: "loading",
  });
  tui.log(`miner address: ${wallet.address}`);
  tui.log(`backend=${options.backend} workers=${options.workers}`);
  tui.log(`read rpc:   ${RPC_URL}`);
  tui.log(`submit rpc: ${SUBMIT_RPC_URL}`);

  await refreshBalance(readContract, wallet.address);

  let currentTarget = 0n;
  let currentEpoch = -1n;

  while (true) {
    const state = await readContract.miningState();
    const difficulty = BigInt(state.difficulty.toString());
    const epoch = BigInt(state.epoch.toString());
    const era = BigInt(state.era.toString());
    const reward = BigInt(state.reward.toString());
    const remaining = BigInt(state.remaining.toString());
    const blocksLeft = BigInt(state.epochBlocksLeft_.toString());
    const challenge = await readContract.getChallenge(wallet.address);

    currentTarget = difficulty;
    currentEpoch = epoch;

    tui.update({
      era: era.toString(),
      reward: `${ethers.formatUnits(reward, 18)} HASH`,
      epoch: epoch.toString(),
      rotatesIn: `${blocksLeft} blk (~${fmtBlocks(blocksLeft)})`,
      target: hex32(difficulty),
      remaining: `${formatHashAmount(remaining)} HASH`,
      challenge,
      eta: "—",
    });
    tui.log(`new round era=${era} epoch=${epoch} reward=${ethers.formatUnits(reward, 18)} HASH`);
    tui.log(`target=${hex32(difficulty).slice(0, 18)}…  expected ~${expected(difficulty).toExponential(2)} hashes/find`);

    let solution;
    try {
      solution = await findSolution({ challenge, difficulty, options });
    } catch (err) {
      tui.update({ status: "error" });
      tui.log(`search failed: ${err.message}`, colors.RED);
      await sleep(2000);
      continue;
    }

    tui.update({ status: "found" });
    tui.log(`found via ${solution.backend}  nonce=${ellipsize(solution.nonce, 20)}  hash=${ellipsize(solution.hash, 20)}`, colors.AMBER);

    await submitSolution({ submitContract, readContract, readProvider, wallet, nonce: BigInt(solution.nonce), options });

    if (!options.keepMining) {
      tui.log("KEEP_MINING=false; exiting after one mint.");
      break;
    }
  }

  tui.cleanup();
}

async function findSolution({ challenge, difficulty, options }) {
  tui.update({ status: "searching", hashrate: 0, hashes: "0", elapsedMs: 0 });
  const startedAt = Date.now();
  const onProgress = ({ backend, hashes, hashrate }) => {
    const elapsedMs = Date.now() - startedAt;
    const etaSec = hashrate > 0 ? expected(difficulty) / hashrate : Infinity;
    tui.update({
      status: "searching",
      hashrate,
      hashes: hashes.toString(),
      elapsedMs,
      eta: etaSec === Infinity ? "—" : `~${fmtSeconds(etaSec)}`,
      backend,
    });
  };

  if (options.backend === "opencl" || options.backend === "auto") {
    const gpu = new OpenClMiner({
      binary: options.gpuBinary,
      batchSize: options.gpuBatchSize,
      onProgress,
    });
    if (gpu.available()) {
      try {
        tui.update({ backend: "opencl", gpuLabel: shortPath(gpu.binary) });
        tui.log(`opencl binary: ${gpu.binary}`, colors.DIM + colors.GREEN);
        return await gpu.search({ challenge, difficulty });
      } catch (err) {
        if (options.backend === "opencl") throw err;
        tui.log(`OpenCL failed, fallback to CPU: ${err.message}`, colors.AMBER);
      }
    } else if (options.backend === "opencl") {
      throw new Error("OpenCL miner belum ada. Jalankan npm run build:opencl atau set OPENCL_MINER_BIN.");
    }
  }

  tui.update({ backend: "cpu", gpuLabel: `${options.workers} workers` });
  const cpu = new CpuMiner({
    workers: options.workers,
    batchSize: options.batchSize,
    onProgress,
  });
  return cpu.search({ challenge, difficulty });
}

async function submitSolution({ submitContract, readContract, readProvider, wallet, nonce, options }) {
  tui.update({ status: "submitting" });
  try {
    const gas = await estimateGas(readContract, wallet.address, nonce);
    const fee = await feeOptions(readProvider, options.priorityFeeGwei);
    const tx = await submitContract.mine(nonce, { gasLimit: gas, ...fee });
    tui.update({ lastTx: tx.hash });
    tui.log(`submitted tx ${tx.hash}`);

    const receipt = await tx.wait();
    if (receipt && receipt.status === 1) {
      tui.update({ status: "confirmed" });
      tui.log(`confirmed in block ${receipt.blockNumber}  gas=${receipt.gasUsed}`, colors.BRIGHT);
      await refreshBalance(readContract, wallet.address);
    } else {
      tui.update({ status: "error" });
      tui.log(`tx reverted in block ${receipt && receipt.blockNumber}`, colors.RED);
    }
  } catch (err) {
    tui.update({ status: "error" });
    tui.log(`tx failed: ${err.shortMessage || err.message}`, colors.RED);
  }
}

async function refreshBalance(contract, address) {
  try {
    if (!contract.balanceOf) {
      const abi = ["function balanceOf(address) view returns (uint256)"];
      const erc = new ethers.Contract(contract.target || CONTRACT_ADDRESS, abi, contract.runner);
      const b = await erc.balanceOf(address);
      tui.update({ balance: `${formatHashAmount(b)} HASH` });
      return;
    }
    const b = await contract.balanceOf(address);
    tui.update({ balance: `${formatHashAmount(b)} HASH` });
  } catch {
    // balanceOf not in ABI; harmless
  }
}

async function estimateGas(contract, from, nonce) {
  try {
    const estimate = await contract.mine.estimateGas(nonce, { from });
    const padded = (estimate * 3n) / 2n;
    if (padded < 200000n) return 200000n;
    if (padded > 450000n) return 450000n;
    return padded;
  } catch {
    return 300000n;
  }
}

async function feeOptions(provider, priorityFeeGwei) {
  const priority = ethers.parseUnits(priorityFeeGwei, "gwei");
  try {
    const block = await provider.getBlock("latest");
    if (block && block.baseFeePerGas) {
      return {
        maxPriorityFeePerGas: priority,
        maxFeePerGas: block.baseFeePerGas * 3n + priority,
      };
    }
  } catch { /* fall through */ }
  return {
    maxPriorityFeePerGas: priority,
    maxFeePerGas: ethers.parseUnits("10", "gwei") + priority,
  };
}

// ── small helpers ────────────────────────────────────────────────────────

function hex32(b) { return "0x" + BigInt(b).toString(16).padStart(64, "0"); }
function expected(target) {
  if (!target || target === 0n) return Infinity;
  return Number((1n << 256n) / BigInt(target));
}
function fmtSeconds(s) {
  if (!isFinite(s) || s <= 0) return "—";
  if (s < 60) return `${s.toFixed(0)}s`;
  if (s < 3600) return `${(s / 60).toFixed(1)}m`;
  if (s < 86400) return `${(s / 3600).toFixed(1)}h`;
  return `${(s / 86400).toFixed(1)}d`;
}
function fmtBlocks(blocks) {
  return fmtSeconds(Number(blocks) * 12);
}
function formatHashAmount(amount) {
  const n = Number(ethers.formatUnits(amount, 18));
  return n.toLocaleString("en-US", { maximumFractionDigits: 2 });
}
function ellipsize(s, max) {
  if (!s || s.length <= max) return s;
  const head = Math.ceil((max - 1) / 2);
  const tail = Math.floor((max - 1) / 2);
  return s.slice(0, head) + "…" + s.slice(-tail);
}
function shortRpc(url) {
  try { return new URL(url).hostname; } catch { return url; }
}
function shortPath(p) {
  if (!p) return "";
  const parts = p.replace(/\\/g, "/").split("/");
  return parts[parts.length - 1];
}
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

process.on("SIGINT", () => {
  tui.log("stopping…", colors.AMBER);
  tui.cleanup();
  process.exit(0);
});

main().catch((err) => {
  tui.cleanup();
  console.error(err.shortMessage || err.message || err);
  process.exit(1);
});
