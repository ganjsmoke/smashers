// Quick visual smoke test of the TUI. No wallet/RPC needed.
const { Tui, colors } = require("./lib/tui");

const tui = new Tui();
tui.update({
  address: "0x7F9D83d39548fA0eaa9C9F9d8e4d3b5C7E2A1B4D",
  backend: "auto",
  submitRpc: "rpc.flashbots.net",
  era: "1",
  reward: "100.0 HASH",
  epoch: "250692",
  rotatesIn: "99 blk (~19.8m)",
  target: "0x0000000000000000000000000000000000000000000000000000000000ffffff",
  remaining: "18,357,000.00 HASH",
  balance: "100.00 HASH",
  challenge: "0x3162d65abfa9fca9b8c4d3e2f1a09876543210fedcba9876543210abcdef1234",
});
tui.log("miner address: 0x7F9D83d39548fA0eaa9C9F9d8e4d3b5C7E2A1B4D");
tui.log("backend=auto workers=9");
tui.log("new round era=1 epoch=250692", colors.DIM + colors.GREEN);

let hashes = 0n;
const rate = 12_850_000;
const start = Date.now();

const tick = setInterval(() => {
  hashes += BigInt(Math.round(rate * 0.5));
  tui.update({
    status: "searching",
    hashrate: rate,
    hashes: hashes.toString(),
    elapsedMs: Date.now() - start,
    eta: "~12.4h",
  });
}, 500);

setTimeout(() => {
  tui.update({ status: "found" });
  tui.log("found via cpu  nonce=0xda19…002b  hash=0x0cca…12df", colors.AMBER);
}, 4000);
setTimeout(() => {
  tui.update({ status: "submitting", lastTx: "0xabc1234def567890abcdef1234567890abcdef1234567890abcdef1234567890" });
  tui.log("submitted tx 0xabc1234def567890abcdef1234567890abcdef1234567890abcdef1234567890");
}, 5500);
setTimeout(() => {
  tui.update({ status: "confirmed", balance: "200.00 HASH" });
  tui.log("confirmed in block 25069321  gas=215000", colors.BRIGHT);
}, 7000);
setTimeout(() => {
  clearInterval(tick);
  tui.cleanup();
  process.exit(0);
}, 8500);
